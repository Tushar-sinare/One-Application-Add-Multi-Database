package com.netwin.transaction.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netwin.transaction.model.Transaction;
import com.netwin.transaction.repository.TransactionRepository;
import com.netwin.transaction.service.TransactionService;
@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository repo;
	
	
	@Override
	public Transaction saveTransaction(Transaction transaction) {
	
		return repo.save(transaction);
	}

}
