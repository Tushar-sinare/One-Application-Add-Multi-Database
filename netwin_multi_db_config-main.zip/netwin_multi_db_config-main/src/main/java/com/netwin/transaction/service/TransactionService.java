package com.netwin.transaction.service;

import com.netwin.transaction.model.Transaction;

public interface TransactionService {

	Transaction saveTransaction(Transaction transaction);

}
