package com.netwin.customer.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.netwin.customer.model.Customer;
import com.netwin.transaction.model.Transaction;

public interface CustomerService {

	Customer saveCustomer(Customer customer);

	List<Transaction> FindByCardNumber(Long cardNumber);

	List<Customer> getAllCustomer();

	List<Transaction> getAllTransaction();

	Customer getCustometId(Long cardNumber);

	

}
