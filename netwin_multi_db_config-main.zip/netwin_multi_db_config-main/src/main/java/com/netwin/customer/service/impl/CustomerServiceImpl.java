package com.netwin.customer.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.netwin.customer.model.Customer;
import com.netwin.customer.repository.CustomerRepository;
import com.netwin.customer.service.CustomerService;
import com.netwin.transaction.model.Transaction;
import com.netwin.transaction.repository.TransactionRepository;
@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
private CustomerRepository repo;

@Autowired
private TransactionRepository tranRepo;
	@Override
	public Customer saveCustomer(Customer customer) {
		
		return repo.save(customer);
	}
	@Override
	public List<Transaction> FindByCardNumber(Long cardNumber) {
	
		return tranRepo.findByCardNumber(cardNumber);
	}
	@Override
	public List<Customer> getAllCustomer() {
		List<Customer> customer = repo.findAll();
		for(Customer cust:customer) {
			List<Transaction>trans = tranRepo.findByCardNumber(cust.getCardNumber());
			cust.setTransaction(trans);
		}
		return customer;
	}
	@Override
	public List<Transaction> getAllTransaction() {
		
		return tranRepo.findAll();
	}
	@Override
	public Customer getCustometId(Long cardNumber) {
Customer cust = repo.findByCardNumber(cardNumber).get();

List<Transaction>trans = tranRepo.findByCardNumber(cust.getCardNumber());
cust.setTransaction(trans);
		return cust;
	}


}
